<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class hello extends CI_Controller {

	public function data($data)
	{
		echo $data;
        //ke folder view/welcome message
	}

    public function tampil(){
        $data['judul'] = "tampil halaman";
        $data['deskripsi'] = "ini deskripsi";

        //parsing data
        $this->load->view('tampil , $data');
    }
}